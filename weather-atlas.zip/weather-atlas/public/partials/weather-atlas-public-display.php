<?php
	
	/**
	 * Provide a public-facing view for the plugin
	 * This file is used to markup the public-facing aspects of the plugin.
	 *
	 * @link       https://www.weather-atlas.com
	 * @package    Weather_Atlas
	 * @subpackage Weather_Atlas/public/partials
	 */

?>
<!-- This file should primarily consist of HTML with a little bit of PHP. -->
